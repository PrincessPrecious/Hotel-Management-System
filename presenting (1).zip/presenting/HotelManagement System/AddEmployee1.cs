﻿//namespace Project3
//{
//    internal class AddEmployee
//    {
//    }
//}